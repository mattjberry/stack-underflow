// app/channels/[name]/posts/[id]/page.tsx
"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import { Post, Reply, Attachment } from "@/types/types";
import styles from "@/channels/channels.module.css";
import { useSession } from "next-auth/react";
import ConfirmDialog from "@/components/ConfirmDialog";
import { useRouter } from "next/navigation";
import Spinner from "@/components/Spinner";
import Image from "next/image";


type PostDetail = Post & {
  replies: Reply[];
  attachments: Attachment[];
}

function AttachmentImage({ attachments, targetType, targetId }: {
  attachments: Attachment[];
  targetType: string;
  targetId: number;
}) {
  const matches = attachments.filter(
    (a) => a.target_type === targetType && a.target_id === targetId
  );
  if (matches.length === 0) return null;

  return (
    <div className={styles.attachments}>
      {matches.map((a) => (
        <img
          key={a.id}
          src={`/api/attachments/${a.id}`}
          alt="Attachment"
          className={styles.attachmentImage}
        />
      ))}
    </div>
  );
}

export default function PostPage() {
  const { name, id } = useParams<{ name: string; id: string }>();
  const [post, setPost] = useState<PostDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [replyFile, setReplyFile] = useState<File | null>(null);
  const { data: session, status } = useSession();
  const [pendingDeletePost, setPendingDeletePost] = useState(false);
  const [pendingDeleteReply, setPendingDeleteReply] = useState<Reply | null>(null);
  const router = useRouter();


  // Track which reply form is open by id, null = post reply form
  const [replyingTo, setReplyingTo] = useState<number | null | undefined>(undefined);
  const [replyBody, setReplyBody] = useState("");

  useEffect(() => {
    async function fetchPost() {
      try {
        const res = await fetch(`/api/channels/${name}/posts/${id}`);
        if (!res.ok) throw new Error("Failed to fetch post");
        const data = await res.json();
        setPost(data);
      } catch (err) {
        setError("Could not load post. Please try again.");
      } finally {
        setLoading(false);
      }
    }
    fetchPost();
  }, [name, id, status]);

  // Delete post handler — navigates back to channel on success
async function handleDeletePost() {
  try {
    const res = await fetch(`/api/admin/posts/${id}`, { method: "DELETE" });
    const data = await res.json();
    if (!res.ok) {
      setError(data.error);
      return;
    }
    router.push(`/channels/${name}`);
  } catch (err) {
    setError("Failed to delete post. Please try again.");
  } finally {
    setPendingDeletePost(false);
  }
}

// Delete reply handler
async function handleDeleteReply() {
  if (!pendingDeleteReply) return;
  try {
    const res = await fetch(`/api/admin/replies/${pendingDeleteReply.id}`, {
      method: "DELETE",
    });
    const data = await res.json();
    if (!res.ok) {
      setError(data.error);
      return;
    }
    // Remove reply and any nested replies from local state
    setPost((prev) => {
      if (!prev) return prev;
      const removeIds = new Set<number>();
      function collectIds(replyId: number) {
        removeIds.add(replyId);
        prev!.replies
          .filter((r) => r.parent_reply_id === replyId)
          .forEach((r) => collectIds(r.id));
      }
      collectIds(pendingDeleteReply.id);
      return {
        ...prev,
        replies: prev.replies.filter((r) => !removeIds.has(r.id)),
      };
    });
  } catch (err) {
    setError("Failed to delete reply. Please try again.");
  } finally {
    setPendingDeleteReply(null);
  }
}

async function handleVote(targetType: "post" | "reply", targetId: number, clickedValue: 1 | -1) {
  if (!post) return;

  // Get the current vote state for this target
  let currentUserVote: 0 | 1 | -1;
  let currentScore: number;
  if (targetType === "post") {
    currentUserVote = post.user_vote;
    currentScore = post.vote_score;
  } else {
    const reply = post.replies.find((r) => r.id === targetId);
    if (!reply) return;
    currentUserVote = reply.user_vote;
    currentScore = reply.vote_score;
  }

  // Clicking same direction removes the vote (toggle off)
  const newUserVote: 0 | 1 | -1 = clickedValue === currentUserVote ? 0 : clickedValue;
  const newScore = currentScore - currentUserVote + newUserVote;

  // Snapshot for rollback on error
  const prevPost = post;

  // Optimistic update
  setPost((prev) => {
    if (!prev) return prev;
    if (targetType === "post") {
      return { ...prev, vote_score: newScore, user_vote: newUserVote };
    }
    return {
      ...prev,
      replies: prev.replies.map((r) =>
        r.id === targetId ? { ...r, vote_score: newScore, user_vote: newUserVote } : r
      ),
    };
  });

  try {
    const res = await fetch("/api/votes", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ targetType, targetId, value: newUserVote }),
    });
    const data = await res.json();
    if (!res.ok) {
      setPost(prevPost);
      setError(data.error || "Failed to vote");
      return;
    }
    // Sync with authoritative values from server
    setPost((prev) => {
      if (!prev) return prev;
      if (targetType === "post") {
        return { ...prev, vote_score: data.vote_score, user_vote: data.user_vote };
      }
      return {
        ...prev,
        replies: prev.replies.map((r) =>
          r.id === targetId ? { ...r, vote_score: data.vote_score, user_vote: data.user_vote } : r
        ),
      };
    });
  } catch (err) {
    setPost(prevPost);
    setError("Failed to vote. Please try again.");
  }
}

async function handleReplySubmit(e: React.SubmitEvent, parentReplyId: number | null) {
  e.preventDefault();
  if (!replyBody.trim()) return;

  try {
    const formData = new FormData();
    formData.append("body", replyBody);
    formData.append("parent_reply_id", parentReplyId?.toString() ?? "");
    if (replyFile) formData.append("attachment", replyFile);

    const res = await fetch(`/api/channels/${name}/posts/${id}`, {
      method: "POST",
      // No Content-Type header — let browser set it for FormData
      body: formData,
    });

    const data = await res.json();
    if (!res.ok) {
      setError(data.error);
      return;
    }

    setPost((prev) =>
      prev ? {
        ...prev,
        replies: [...prev.replies, {
          ...data,
          vote_score: 0,
          user_vote: 0,
          author_name: session?.user.name ?? "You",
        }]
      } : prev
    );
    setReplyBody("");
    setReplyFile(null);
    setReplyingTo(undefined);

  } catch (err) {
    setError("Failed to post reply. Please try again.");
  }
}

  function formatScore(score: number) {
    if (score > 0) return `+${score}`;
    return `${score}`;
  }

function renderReplyForm(parentReplyId: number | null) {
  return (
    <form
      className={styles.form}
      onSubmit={(e) => handleReplySubmit(e, parentReplyId)}
    >
      <div className={styles.formGroup}>
        <label htmlFor={`reply-${parentReplyId}`}>Your Reply</label>
        <textarea
          id={`reply-${parentReplyId}`}
          rows={3}
          value={replyBody}
          onChange={(e) => setReplyBody(e.target.value)}
          placeholder="Write your reply..."
          required
        />
      </div>
      <div className={styles.formGroup}>
        <label htmlFor={`attachment-${parentReplyId}`}>
          Screenshot (optional)
        </label>
        <input
          id={`attachment-${parentReplyId}`}
          type="file"
          accept=".png,.jpg,.jpeg,.webp"
          onChange={(e) => setReplyFile(e.target.files?.[0] ?? null)}
        />
        {replyFile && (
          <p className={styles.cardMeta}>
            Selected: {replyFile.name} ({(replyFile.size / 1024 / 1024).toFixed(2)} MB)
          </p>
        )}
      </div>
      <div className={styles.formActions}>
        <button type="submit" className={styles.button}>
          Submit Reply
        </button>
        <button
          type="button"
          className={styles.button}
          onClick={() => {
            setReplyingTo(undefined);
            setReplyBody("");
            setReplyFile(null);
          }}
        >
          Cancel
        </button>
      </div>
    </form>
  );
}

function renderReplies(
  replies: Reply[],
  parentId: number | null = null,
  depth = 0
) {
  const filtered = replies.filter((r) => r.parent_reply_id === parentId);
  if (filtered.length === 0) return null;

  // Use div for nested replies to avoid <li> inside <li>
  const Tag = depth === 0 ? "li" : "div";

  const items = filtered.map((reply) => {
    const isReplyAuthor =
      status === "authenticated" &&
      parseInt(session!.user.id) === reply.author_id;

    return (
      <Tag key={reply.id} className={styles.replyCard}>
        <p className={styles.postCardBody}>{reply.body}</p>
        <AttachmentImage
          attachments={post!.attachments}
          targetType="reply"
          targetId={reply.id}
        />
        <div className={styles.postCardFooter}>
          <div className={styles.postCardLeft}>
            <p className={styles.cardMeta}>
              {reply.author_name} ·{" "}
              {new Date(reply.created_at).toLocaleDateString()}
            </p>
            <div
              className={`${styles.votes} ${
                status !== "authenticated" || isReplyAuthor
                  ? styles.votesLocked : ""
              }`}
              data-tooltip={
                isReplyAuthor
                  ? "You cannot vote on your own content"
                  : "Please sign in to vote"
              }
            >
              <button
                className={`${styles.voteButton} ${
                  reply.user_vote === 1 ? styles.voteButtonActive : ""
                }`}
                disabled={status !== "authenticated" || isReplyAuthor}
                onClick={() => handleVote("reply", reply.id, 1)}
              >
                <Image
                  src="/thumbs-up.png"
                  alt="Upvote"
                  width={18}
                  height={18}
                /> 
              </button>
              <span>{formatScore(reply.vote_score)}</span>
              <button
                className={`${styles.voteButton} ${
                  reply.user_vote === -1 ? styles.voteButtonActive : ""
                }`}
                disabled={status !== "authenticated" || isReplyAuthor}
                onClick={() => handleVote("reply", reply.id, -1)}
              >
                <Image
                  src="/thumbs-down.png"
                  alt="Downvote"
                  width={18}
                  height={18}
                /> 
              </button>
            </div>
          </div>
          <div className={styles.postCardActions}>
            {status === "authenticated" ? (
              <button
                className={styles.button}
                onClick={() => setReplyingTo(reply.id)}
              >
                Reply
              </button>
            ) : (
              <p className={styles.authPrompt}>Please sign in to reply</p>
            )}
            {status === "authenticated" && session?.user.role === "admin" && (
              <button
                className={styles.deleteButton}
                onClick={() => setPendingDeleteReply(reply)}
              >
                Delete Reply
              </button>
            )}
          </div>
        </div>

        {replyingTo === reply.id && renderReplyForm(reply.id)}

        {replies.some((r) => r.parent_reply_id === reply.id) && (
          <div className={styles.nestedReplies}>
            {renderReplies(replies, reply.id, depth + 1)}
          </div>
        )}
      </Tag>
    );
  });

  return depth === 0 ? (
    <ul className={styles.replyList}>{items}</ul>
  ) : (
    <>{items}</>
  );
}

  if (loading) return <Spinner message="Loading post..." />;
  if (error) return <p className={styles.error}>{error}</p>;
  if (!post) return <p className={styles.empty}>Post not found.</p>;

  const isPostAuthor = status === "authenticated" &&
    parseInt(session!.user.id) === post.author_id;

  return (
    <div className={styles.container}>

      {/* Main post card */}
      <div className={styles.postCard}>
        <h1 className={styles.postCardTitle}>{post.title}</h1>
        <p className={styles.postCardBody}>{post.body}</p>
        <AttachmentImage
          attachments={post.attachments}
          targetType="post"
          targetId={post.id}
        />
        <div className={styles.postCardFooter}>
          <div className={styles.postCardLeft}>
            <p className={styles.cardMeta}>
              Posted by {post.author_name} ·{" "}
              {new Date(post.created_at).toLocaleDateString()}
            </p>
            <div
              className={`${styles.votes} ${
                status !== "authenticated" || isPostAuthor ? styles.votesLocked : ""
              }`}
              data-tooltip={
                isPostAuthor
                  ? "You cannot vote on your own content"
                  : "Please sign in to vote"
              }
            >
              <button
                className={`${styles.voteButton} ${
                  post.user_vote === 1 ? styles.voteButtonActive : ""
                }`}
                disabled={status !== "authenticated" || isPostAuthor}
                onClick={() => handleVote("post", post.id, 1)}
              >
                <Image
                  src="/thumbs-up.png"
                  alt="Upvote"
                  width={18}
                  height={18}
                /> 
              </button>
              <span>{formatScore(post.vote_score)}</span>
              <button
                className={`${styles.voteButton} ${
                  post.user_vote === -1 ? styles.voteButtonActive : ""
                }`}
                disabled={status !== "authenticated" || isPostAuthor}
                onClick={() => handleVote("post", post.id, -1)}
              >
                <Image
                  src="/thumbs-down.png"
                  alt="Downvote"
                  width={18}
                  height={18}
                /> 
              </button>
            </div>
          </div>
          <div className={styles.postCardActions}>
            {status === "authenticated" ? (
              <button
                className={styles.button}
                onClick={() => setReplyingTo(null)}
              >
                Reply
              </button>
            ) : (
              <p className={styles.authPrompt}>Please sign in to reply</p>
            )}
            {status === "authenticated" && session?.user.role === "admin" && (
              <button
                className={styles.deleteButton}
                onClick={() => setPendingDeletePost(true)}
              >
                Delete Post
              </button>
            )}
          </div>
        </div>
        {replyingTo === null && renderReplyForm(null)}
      </div>

      <h2 className={styles.title}>
        Replies ({post.replies.length})
      </h2>

      {post.replies.length === 0 ? (
        <p className={styles.empty}>No replies yet. Be the first to respond!</p>
      ) : (
        renderReplies(post.replies)
      )}

      {pendingDeletePost && (
        <ConfirmDialog
          message="Delete this post?"
          subMessage="This will permanently delete all replies and attachments."
          onConfirm={handleDeletePost}
          onCancel={() => setPendingDeletePost(false)}
        />
      )}
      {pendingDeleteReply && (
        <ConfirmDialog
          message="Delete this reply?"
          subMessage="This will permanently delete any nested replies."
          onConfirm={handleDeleteReply}
          onCancel={() => setPendingDeleteReply(null)}
        />
      )}
    </div>
  );
}